package com.portolio.michi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MichiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MichiApplication.class, args);
	}

}
