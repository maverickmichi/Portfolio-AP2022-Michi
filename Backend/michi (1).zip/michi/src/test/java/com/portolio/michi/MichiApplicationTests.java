package com.portolio.michi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MichiApplicationTests {

	@Test
	void contextLoads() {
	}

}
